import NewsForm from '@/components/forms/NewsForm';

export default function CreateNewsPage() {
  return <NewsForm />;
}
